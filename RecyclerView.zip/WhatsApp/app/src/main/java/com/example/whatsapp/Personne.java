package com.example.whatsapp;

public class Personne {
    private String nom, email, tele;
    private  int image;

    public Personne(String nom, String email, String tele, int image) {
        this.nom = nom;
        this.email = email;
        this.tele = tele;
        this.image = image;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTele(String tele) {
        this.tele = tele;
    }

    public String getEmail() {
        return email;
    }

    public String getTele() {
        return tele;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
