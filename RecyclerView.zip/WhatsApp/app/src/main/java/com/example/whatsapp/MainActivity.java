package com.example.whatsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);

        List<Personne> personnes = new ArrayList<>();
        personnes.add(new Personne("karim Hololo", "karimhololo@gmail.com", "0656879625", R.drawable.profile_1));
        personnes.add(new Personne("manal tabit", "manaltabit@gmail.com", "065682809825", R.drawable.profile_2));
        personnes.add(new Personne("layla komin", "laylaKomin@gmail.com", "06556265625", R.drawable.profile_3));
        personnes.add(new Personne("nadir jhuh", "nadirhgdy@gmail.com", "0656767625", R.drawable.profile_4));
        personnes.add(new Personne("travis Scott", "travissc@gmail.com", "06589779625", R.drawable.profile_5));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        MyAdapter adapter = new MyAdapter(this, personnes);
        recyclerView.setAdapter(adapter);

    }
}