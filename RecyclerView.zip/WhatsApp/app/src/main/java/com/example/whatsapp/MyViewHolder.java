package com.example.whatsapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Objects;

public class MyViewHolder extends RecyclerView.ViewHolder {
    TextView nom, email, tele;
    ImageView image;

    public  MyViewHolder(@NonNull View personneView){
        super(personneView);
        nom = personneView.findViewById(R.id.nom);
        email = personneView.findViewById(R.id.email);
        tele = personneView.findViewById(R.id.tel);
        image = personneView.findViewById(R.id.image);
    }
}
