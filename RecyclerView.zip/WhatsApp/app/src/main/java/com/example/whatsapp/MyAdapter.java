package com.example.whatsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private Context context;
    private List<Personne> personnes;

    public MyAdapter(Context context, List<Personne> personnes){
        this.context = context;
        this.personnes = personnes;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.personne_view, null, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Personne p= personnes.get(position);
        holder.nom.setText(p.getNom());
        holder.tele.setText(p.getTele());
        holder.email.setText(p.getEmail());
        holder.image.setImageResource(p.getImage());
    }

    @Override
    public int getItemCount() {
        return personnes.size();
    }
}
